import UIKit
import Foundation


//Function
func topla(_ sayi1: Int, _ sayi2: Int) -> Int{
    return sayi1 + sayi2
}

var sonuc = topla(10, 20)
print(sonuc)

//Closure
var closureIleToplama : (Int,Int) -> (Int) = { sayi1 , sayi2 in
    return sayi1 + sayi2
}

closureIleToplama(10,20)

//Closure Kısa
var closureIleToplamaKisa : (Int,Int) -> (Int) = {
    return $0 + $1
}

closureIleToplamaKisa(10,20)

//Fonksiyona parametre olarak closure verme
func buyukOlanlariFiltrele(deger:Int, sayilar:[Int]) -> [Int] {
    var filtrelenmisDizi = [Int]()
    for sayi in sayilar{
        if sayi > deger {
            filtrelenmisDizi.append(sayi)
        }
    }
    return filtrelenmisDizi
}

let filtrelenmisler = buyukOlanlariFiltrele(deger: 3, sayilar: [1,2,3,4,5,7,9])
print(filtrelenmisler)

//5ten küçük degerler
func closureIleFiltreleme(closure: (Int) -> Bool, sayilar: [Int]) -> [Int] {
    var filtrelenmisDizi = [Int]()
    for sayi in sayilar{
        if closure(sayi){
            filtrelenmisDizi.append(sayi)
        }
    }
    return filtrelenmisDizi
}

let filtrelenmisler2 = closureIleFiltreleme(closure: { (sayi) -> Bool in
    return sayi > 2
}, sayilar: [1,2,3,4,5,10])

//5'e bölünebilen sayilari filtreleyen closure
func beseBolunebilenler(sayi: Int) -> Bool {
    return sayi % 5 == 0
}

let filtrelemeDizi = closureIleFiltreleme(closure: beseBolunebilenler, sayilar: [20,30,45,8,9,21])

//closure toplama islemi
let toplamaIslemi: (Int,Int) -> Int = { (x: Int, y:Int) in
    return x + y
}

toplamaIslemi(6,5)

//daha kısa şekli
let toplamaIslemiKisa: (Int,Int) -> Int = { (x,y) in
    return x + y
}
toplamaIslemiKisa(8,9)

//diğer bir kısa şekli
let toplamaIslemiKisaV2 = { (x:Int, y:Int) in
    return x + y
}

toplamaIslemiKisaV2(5,4)

//daha kısa şekli
let toplamaIslemiDahaKisa: (Int, Int) -> Int = {return $0 + $1}
toplamaIslemiDahaKisa(7,8)

//en kısa şekli
let toplamaIslemiEnKisa: (Int, Int) -> Int = {$0 + $1}
toplamaIslemiEnKisa(6,3)

//CLOSURE İLE VİEW CONTROLLER ARASI OBSERVİNG
class AVC: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func firstButtonClick(_ sender: Any) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        if let destVC = sb.instantiateViewController(withIdentifier: "BVC") as? BVC{
            destVC.successListener = { hello in
                let sb = UIStoryboard(name: "Main", bundle: nil)
                if let destVC = sb.instantiateViewController(withIdentifier: "CVC") as? CVC{
                    destVC.helloStr = hello
                    self.navigationController?.pushViewController(destVC, animated: true)
                }
            }
            self.present(destVC, animated: false, completion: nil)
        }
    }
}


class BVC: UIViewController{
    
    
    typealias SuccessListener = (_ str: String) -> ()
    var successListener: SuccessListener?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func secondButtonClick(_ sender: Any) {
        self.dismiss(animated: false, completion: {
            self.successListener?("Hello World")
        })
    }
}


class CVC: UIViewController{
        
        var helloStr: String = ""
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            print(helloStr)
        }
    }

